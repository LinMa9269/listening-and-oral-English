#!/bin/bash
# Finder opens .command files in Terminal. Keep paths quoted for spaces / Chinese names.
cd -- "$(dirname -- "$0")" || exit 1
finish() {
  printf '\n按回车键关闭窗口。Press Return to close.\n'
  read -r unused
}
if [ "$(uname -s)" != "Darwin" ] || [ "$(uname -m)" != "x86_64" ]; then
  printf '此启动入口适用于 Intel Mac。Windows 请使用 start.bat。\n'
  finish
  exit 1
fi
mac_version=$(sw_vers -productVersion)
if [ "${mac_version%%.*}" -lt 13 ]; then
  printf '此包需要 macOS 13 Ventura 或更新版本。请查看 Mac使用说明.md。\n'
  finish
  exit 1
fi
python_path=''
for candidate in \
  /Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13 \
  /Library/Frameworks/Python.framework/Versions/3.12/bin/python3.12 \
  /Library/Frameworks/Python.framework/Versions/3.11/bin/python3.11 \
  /usr/local/bin/python3.13 /usr/local/bin/python3.12 /usr/local/bin/python3.11 \
  "$(command -v python3.13)" "$(command -v python3.12)" "$(command -v python3.11)"; do
  if [ -n "$candidate" ] && [ -x "$candidate" ] && "$candidate" -c 'import sys, platform; sys.exit(not ((3,11) <= sys.version_info[:2] <= (3,13) and platform.machine() == "x86_64"))' >/dev/null 2>&1; then
    python_path="$candidate"
    break
  fi
done
if [ -z "$python_path" ]; then
  printf '请先安装 Python 3.13 的 macOS 安装包，然后重新双击此文件。\n也支持 Python 3.11 / 3.12。详见 Mac使用说明.md。\n'
  finish
  exit 1
fi
printf '正在启动 Listen Lab。首次安装与下载模型需要联网。\n使用期间请保留这个窗口；按 Control+C 停止服务。\n'
"$python_path" launcher.py
result=$?
if [ "$result" -ne 0 ]; then
  printf '\n启动未完成。请保留上面的错误信息，并参照 Mac使用说明.md。\n'
fi
finish
exit "$result"
