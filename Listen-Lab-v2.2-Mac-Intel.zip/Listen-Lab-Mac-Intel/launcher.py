"""One-click setup; no administrator privileges or account keys required."""
import os
import platform
from pathlib import Path
import subprocess
import sys
import threading
import time
import urllib.request
import webbrowser

ROOT = Path(__file__).resolve().parent
os.chdir(ROOT)
if sys.version_info < (3, 10):
    raise SystemExit('Please install Python 3.11 or newer from https://www.python.org/downloads/')
mac_intel = sys.platform == 'darwin' and platform.machine() == 'x86_64'
if mac_intel and not (3, 11) <= sys.version_info[:2] <= (3, 13):
    raise SystemExit('Intel Mac: please install Python 3.13 (or 3.11 / 3.12).')
if mac_intel and int(platform.mac_ver()[0].split('.')[0]) < 13:
    raise SystemExit('This Intel Mac package requires macOS 13 Ventura or newer. See Mac使用说明.md.')
environment = ROOT / ('.venv-mac-intel' if mac_intel else '.venv')
runtime = environment / ('Scripts/python.exe' if os.name == 'nt' else 'bin/python')
requirements = ROOT / ('requirements-mac-intel.txt' if mac_intel else 'requirements.txt')
if not runtime.exists():
    print('First setup: creating local Python environment...', flush=True)
    subprocess.run([sys.executable, '-m', 'venv', str(environment)], check=True)
dependency_check = "import faster_whisper, yt_dlp, av; assert av.__version__ == '16.1.0'"
if mac_intel:
    dependency_check += "; import ctranslate2, onnxruntime; assert ctranslate2.__version__ == '4.6.0'; assert onnxruntime.__version__ == '1.23.2'"
installed = subprocess.run([str(runtime), '-c', dependency_check], capture_output=True)
if installed.returncode:
    print('Installing local transcription and link components. This may take several minutes...', flush=True)
    result = subprocess.run([str(runtime), '-m', 'pip', 'install', *(['--only-binary=:all:'] if mac_intel else []), '-r', str(requirements)])
    if result.returncode:
        print('Dependency installation failed. Library and subtitle import remain available. Restart later to retry.', flush=True)
port = os.environ.get('LISTEN_LAB_PORT', '8765')
url = 'http://127.0.0.1:' + port
env = os.environ.copy()
env.setdefault('HF_HOME', str(ROOT / 'models'))
try:
    response = urllib.request.urlopen(url + '/api/health', timeout=1)
    if response.status == 200:
        print('A local service already uses this port. Opening it; close the previous server to switch libraries.', flush=True)
        webbrowser.open(url)
        raise SystemExit(0)
except OSError:
    pass

def show_when_ready():
    for _ in range(60):
        try:
            with urllib.request.urlopen(url + '/api/health', timeout=1) as response:
                if response.status == 200:
                    webbrowser.open(url)
                    return
        except OSError:
            time.sleep(0.5)

threading.Thread(target=show_when_ready, daemon=True).start()
print('Starting Listen Lab. Keep this window open while learning.', flush=True)
try:
    subprocess.run([str(runtime), str(ROOT / 'server.py')], env=env, check=True)
except KeyboardInterrupt:
    pass
