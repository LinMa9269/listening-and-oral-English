# Listen Lab 2.2 · Intel Mac 启动包

你的配置：Intel 芯片、macOS Ventura 13.7.8，符合本包的系统版本要求。需安装 Python 3.11–3.13。此包保留 2.2 的视频库、生词存档、30 天回收站和片段范围调整。

## 第一次使用

1. 安装 Python 3.13 的 macOS 安装包，选择常规版本，不选实验性 free-threaded 版本。官方下载列表：https://www.python.org/downloads/macos/ 。已安装 Python 3.11 或 3.12 的也可以继续使用。
2. 双击 ZIP 解压，将完整文件夹放在固定且可写的位置，例如「文稿/Listen Lab」。不要只复制 HTML 或启动文件。
3. 双击 **Start-Listen-Lab.command**。它会打开终端窗口，创建专用运行环境并安装识别组件，然后打开浏览器。
4. 首次上传视频还需下载约 150 MB 的本地识别模型。等待完成后即可按原来的方式练习。

以后仍双击同一个启动文件。使用期间保持终端窗口运行；按 Control+C 停止服务。浏览器未自动弹出时，手动打开 http://127.0.0.1:8765 。不要双击 Windows 的 start.bat。

视频在本机识别，不需要 OpenAI API 密钥。Intel Mac 使用 CPU，长视频可能需要较久；建议先用一小段英语视频确认运行效果。

## 保留原来的学习记录

先关闭旧版启动窗口，再把旧程序的完整 **data** 和 **models** 文件夹复制到 Mac 新程序旁。视频、生词、字幕、回收站和已保存片段范围都在 data 中。不要把 Windows 的 .venv 运行环境搬过来；Mac 会自行建立 .venv-mac-intel。

不要同时启动两个版本操作同一个 data 文件夹。备份时关闭程序并复制完整 data。

## 无法打开时

- 找不到 Python：确认安装的是 Python 3.11–3.13，而不是仅安装最新的 3.14 / 3.15。
- 提示没有执行权限：打开「终端」，输入 `bash `（末尾留空格），将 **Start-Listen-Lab.command** 拖入窗口，再按回车，即可运行同一个启动脚本。
- macOS 阻止打开：确认文件来自本次交付后，按系统提示在「系统设置 → 隐私与安全性」中处理这个文件的打开请求；无需关闭系统整体安全保护。
- 下载报证书错误：如果使用 python.org 安装包，到「应用程序 → Python 3.13」（或实际版本）运行随附的 **Install Certificates.command**，再重试。
- 组件安装失败：程序会尝试保留手动字幕模式；保存错误信息以便排查。不要反复重新上传同一视频。
- 旧系统：此版本按 macOS 13+ 的 Intel 识别组件制作。macOS 12 及更早版本需另行核对，不能保证自动识别可用。

## 验证范围

已核对 PyPI 的 Intel Mac 预编译包，并固定 CTranslate2 4.6.0、ONNX Runtime 1.23.2、PyAV 16.1.0。ONNX Runtime 这个版本的 Intel 包要求 macOS 13+。

- https://pypi.org/project/ctranslate2/4.6.0/
- https://pypi.org/project/onnxruntime/1.23.2/
- https://pypi.org/project/av/16.1.0/

交付环境是 Windows，不能在这里验证 Intel Mac 实机安装、Finder 双击和 Safari 播放。此包是为 Mac 准备的启动脚本与源码包，并非已签名、公证的 .app 安装包；它不包含 Python 和语音模型。
